library(e1071);
mnistImages<-matrix(0,2000,784,FALSE,NULL);
ImageData<-as.matrix(read.table("mnistImages.txt"));
mnistLabels<-as.vector(read.table("mnistLabels.txt"));
for(i in 1:2000)
{
  mnistImages[i,]=ImageData[((i-1)*28+1):(i*28),];
}
mnistImages<-cbind(mnistLabels,mnistImages);
j<-2;
list.test.accuracy<-c();
list.data.scale<-c();
  index<-sample(1:2000,1600);
  mnistImages.train<-mnistImages[index,];
  mnistImages.test<-mnistImages[-index,];
  mnistImages.train.labels<-mnistImages.train[,1];
  
  mnistImages.train<-mnistImages.train[,-1];
  mnistImages.train.temp<-mnistImages.train;
  mnistImages.test.labels<-mnistImages.test[,1];
  mnistImages.test<-mnistImages.test[,-1];
  mnistImages.test.temp<-mnistImages.test;
while(j<=200)
{  
  mnistImages.train<-mnistImages.train.temp;
  mnistImages.test<-mnistImages.test.temp;
  nw <- cov(mnistImages.train);
  nd <- svd(nw);
  u <- nd$u[,1:j];
  mnistImages.train.names<-colnames(mnistImages.train);
  mnistImages.train.names<-mnistImages.train.names[1:j];
  mnistImages.train<- as.matrix(mnistImages.train);
  mnistImages.train<-mnistImages.train%*% u;
  #colnames(mnistImages.train) <-mnistImages.train.names;
  label=as.factor(mnistImages.train.labels);
  dataset =data.frame(label,mnistImages.train);
  model = svm(label ~., data = dataset, kernel = "polynomial", degree = 2);
  mnistImages.test<-as.matrix(mnistImages.test);
  mnistImages.test<-mnistImages.test%*%u;
  pred = predict(model, newdata =mnistImages.test);
  #if(j==2000) 
  #{
   # predictions = data.frame(ImageId=1:nrow(mnistImages.test), Pre_Label=pred,Label=mnistImages.test.labels);
    #write.csv(predictions,"predictions-new.csv", row.names= FALSE);
  #}
  err<-0;
  #err_list<-c();
  for(i in 1:nrow(as.matrix(mnistImages.test.labels)))
  {
    if(mnistImages.test.labels[i]!=pred[i])
    {
      err<-err+1;
      #err_list<-c(err_list,i);
    }
  }
  list.test.accuracy<-c(list.test.accuracy,1-(1.0*err)/(1.0*nrow(as.matrix(mnistImages.test.labels))));
  list.data.scale<-c(list.data.scale,j); 
  j<-j+5;
}
plot(list.data.scale,list.test.accuracy);
lines(list.data.scale,list.data.scale)