install.packages("e1071");
library(e1071);
mnistImages<-matrix(0,2000,784,FALSE,NULL);
ImageData<-as.matrix(read.table("mnistImages.txt"));
mnistLabels<-as.vector(read.table("mnistLabels.txt"));
for(i in 1:2000)
{
  mnistImages[i,]=ImageData[((i-1)*28+1):(i*28),];
}
mnistImages<-cbind(mnistLabels,mnistImages);
index<-sample(1:nrow(mnistImages),1600);
mnistImages.train<-mnistImages[index,];
mnistImages.test<-mnistImages[-index,];
mnistImages.train.labels<-mnistImages.train[,1];
mnistImages.train<-mnistImages.train[,-1];
mnistImages.test.labels<-mnistImages.test[,1];
mnistImages.test<-mnistImages.test[,-1];
nw <- cov(mnistImages.train);
nd <- svd(nw);
u <- nd$u[,1:120];
mnistImages.train.names<-colnames(mnistImages.train);
mnistImages.train.names<-mnistImages.train.names[1:120];
mnistImages.train<- as.matrix(mnistImages.train);
mnistImages.train<-mnistImages.train%*% u;
#colnames(mnistImages.train) <-mnistImages.train.names;
label=as.factor(mnistImages.train.labels);
dataset =data.frame(label,mnistImages.train);
model = svm(label ~., data = dataset, kernel = "polynomial", degree = 2);
mnistImages.test<-as.matrix(mnistImages.test);
mnistImages.test<-mnistImages.test%*%u;
pred = predict(model, newdata =mnistImages.test);
predictions = data.frame(ImageId=1:nrow(mnistImages.test), Pre_Label=pred,Label=mnistImages.test.labels);
#write.csv(predictions,"predictions-new.csv", row.names= FALSE);
err<-0;
err_list<-c();
for(i in 1:nrow(as.matrix(mnistImages.test.labels)))
{
  if(mnistImages.test.labels[i]!=pred[i])
  {
    err<-err+1;
    err_list<-c(err_list,i);
  }
}
pred.train = predict(model, newdata =mnistImages.train);
err.train<-0;
err_list.train<-c();
for(i in 1:nrow(as.matrix(mnistImages.train.labels)))
{
    if(mnistImages.train.labels[i]!=pred.train[i])
    {
      err.train<-err.train+1;
      err_list.train<-c(err_list.train,i);
    } 
}

